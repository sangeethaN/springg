package demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;


public class TestRowMapper implements RowMapper<Test> {

	public Test mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		Test testObj =new Test();
		testObj.setIdentity(rs.getString(1));
		testObj.setName(rs.getString(2));
		testObj.setQuantityInStock(rs.getInt(3));
		testObj.setMaximumRetailPrice(rs.getDouble(4));
		testObj.setDiscount(rs.getDouble(5));
		testObj.setVendor(rs.getString(6));
		testObj.setManufacturingDate(rs.getString(7));
		testObj.setExpiryDate(rs.getString(8));
		
		
//		testObj.setTestDuration(rs.getString(3));
		//testObj.setTestCreatedTs(DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		//System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" +rs.getTimestamp(5));
		//System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		//testObj.setTestChargeBack(rs.getString(6));
		return testObj;
	}

}
