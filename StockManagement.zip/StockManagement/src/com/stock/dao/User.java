package com.stock.dao;

public class User {
 private String userId;
 private String userName;
 private String usertype;
 private String userPassword;
 private String email;
 private String phoneNumber;
public User(String userId, String userName, String usertype,String userPassword, String email,
		String phoneNumber) {
	super();
	this.userId = userId;
	this.userName = userName;
	this.usertype = usertype;
	this.userPassword = userPassword;
	this.email = email;
	this.phoneNumber = phoneNumber;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUsertype() {
	return usertype;
}
public void setUsertype(String usertype) {
	this.usertype = usertype;
}
public String getUserPassword() {
	return userPassword;
}
public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
 
 
}
