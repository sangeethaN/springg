package com.stock.dao;

import java.awt.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

import com.stock.utils.Database;

public class ItemDao {
	String ide = "";
	String names ="";
	int qunty = 0;
	double disc = 0.0;
	double mrpr = 0.0;
	String ven ="";
public void update(String id,String name,String qty ,String dis ,String mrp ,String vendor) throws SQLException 
{
	ide = id;
	names = name;
	qunty = Integer.parseInt(qty);
	disc = Double.parseDouble(dis);
	mrpr = Double.parseDouble(mrp);
	ven = vendor;
	Database db = new Database();
	PreparedStatement ps = db.getPS("UPDATE xbbnhhm_stocks_product SET NAME=?,QUANTITYINSTOCK=?,MAXIMUMRETAILPRICE=?,DISCOUNT=?,VENDOR=? WHERE PRODUCTIDENTITY=?");
	ps.setString(6, ide);
	ps.setString(1, names);
	ps.setInt(2, qunty);
	ps.setDouble(3,mrpr);
	ps.setDouble(4, disc);
	ps.setString(5,ven);
	ps.executeUpdate();
	db.close();
	
}
public ArrayList<Item> display() throws SQLException
{
	ArrayList<Item> all = new ArrayList<Item>();
	Database db = new Database();
	PreparedStatement ps = db.getPS("SELECT * FROM xbbnhhm_stocks_product");
	ResultSet rs = ps.executeQuery();
	while(rs.next()) {
		all.add(new Item(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getDouble(4), rs.getDouble(5), rs.getString(6), rs.getString(7), rs.getString(8)));
	}	
return all;
}
}
