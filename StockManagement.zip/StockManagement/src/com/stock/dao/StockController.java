package com.stock.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/stocks")
public class StockController {

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<Item> getAllStocks() throws SQLException {

		System.out.println("success");
		ItemDao da = new ItemDao();
		ArrayList<Item> all = new ArrayList<Item>();
		all = da.display();

		return all;
	}

}
