package com.stock.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Database {
	private Connection connection;
	private PreparedStatement ps;
	public void close() {
		try {
			if(ps != null) {
				ps.close();
			}
			if(connection != null) {
				connection.close();
			}
		} catch(Exception e) {}
	}
	public PreparedStatement getPS(String query) {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			connection = DriverManager.getConnection("jdbc:derby://172.24.18.178:1527/sangeetha","user","pwd");
			ps = connection.prepareStatement(query);
			return ps;
		} catch(Exception e) {
			System.out.println(e);
			return null;
		}
	}
}

