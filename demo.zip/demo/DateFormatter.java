package demo;


import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DateFormatter {

	
	public static String getNexenFormatDate(Timestamp createdTS){
		
		String nexenDateTimePattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        SimpleDateFormat sdf = new SimpleDateFormat(nexenDateTimePattern);
        String formattedDateStr = sdf.format(createdTS);
       // String pattern = "YYYY-MM-DD HH:mm:ss.SS";
       
       /*// SimpleDateFormat sdf1 = new SimpleDateFormat(nexenDateTimePattern);
        Date date = null;
		try {
			date = sdf1.parse(formattedDateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return formattedDateStr;
		
		
	}

	
}
